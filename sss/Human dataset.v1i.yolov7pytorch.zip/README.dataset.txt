# Human dataset > 2024-12-01 5:06pm
https://universe.roboflow.com/abdelrahman-afify/human-dataset-fkxwo

Provided by a Roboflow user
License: CC BY 4.0

